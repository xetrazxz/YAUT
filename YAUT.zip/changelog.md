### v1.0 - 30.6.2025
* Initial release