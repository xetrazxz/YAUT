# YAUT - Yet Another Useless Tweak

YAUT is a YAUT

## Features

- Nothing Interesting

## Installation

1. If U Know U Know

## Compatibility

Snapdragon-based devices  

> **Disclaimer:**  
> This module is called *Yet Another Useless Tweak* for a reason — use at your own risk.  

## Credits

- xetrazxz

## License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

**Enjoy tweaking, or at least pretending to! 🤘**